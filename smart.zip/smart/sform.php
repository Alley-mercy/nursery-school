<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<form action="/action_page.php">
  <fieldset>
    <legend>Student Registration Form:</legend>
    <label for="fname">First name:</label>
    <input type="text" id="fname" name="fname" value="John"><br>
    <label for="lname">Last name:</label>
     <input type="text" id="lname" name="lname" value="Doe"><br><br>
    <label for="country">Country &nbsp;&nbsp;&nbsp;&nbsp;</label>
	    <select id="country" name="country">
	      <option >Rwanda</option>
	      <option >Burundi</option>
	      <option >Tanzania</option>
	    </select><br>
	    <label>Gender</label>
	    Male <input type="radio" name="">
	    Female <input type="radio" name="">
	    <br><br>
	    <label>Date of Birth</label>
	    <input type="date" name=""><br>

	    <label for="country">Department</label>
	    <select id="country" name="country">
	      <option >Primary</option>
	      <option >O level</option>
	      <option >A level</option>
	    </select><br>
    
    <input type="submit" value="Submit">
  </fieldset>
</form>
</body>
</html>
