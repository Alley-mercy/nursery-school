<!DOCTYPE html>
<html>
<head>
	<title>SCHOOL MANAGEMENT SYSTEM</title>
</head>

<body bgcolor="skyblue">
		<?php
include('header.php');
	?>
<div id="formset">
	  <form>
	  	
  <fieldset>
  		
    <legend>Teachers' Form:</legend>
    	
    <label for="fname">First name:</label>
    <input type="text" id="fname" name="fname" value=""><br>
    <label for="lname">Last name:</label>
    <input type="text" id="lname" name="lname" value=""><br>
	    <label>Gender</label>
	    Male <input type="radio" name="">
	    Female <input type="radio" name="">
	    <br><br>
	   	<label for="country">Department &nbsp;&nbsp;</label>
	    <select id="country" name="country">
	      <option >Primary</option>
	      <option >O level</option>
	      <option >A level</option>
	    </select><br><br>
    		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Submit">
    		
  		</fieldset>
	</form>
</div>
</body>
	<?php
include('footer.php');
?>
</html>