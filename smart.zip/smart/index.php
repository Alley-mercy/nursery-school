<!DOCTYPE html>
<html>
<head>
	<title>SCHOOL MANAGEMENT SYSTEM</title>
</head>
<style>
img {
	  max-width: 100%;
	  height: auto;
	}
</style>

<body>
	<?php
include('header.php');
	?>
	<img src="img/mrc.jpg">
<?php
include('footer.php');
?>

</body>
</html>