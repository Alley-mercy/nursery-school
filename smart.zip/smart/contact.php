<!DOCTYPE html>
<html>
<head>
	<title>SCHOOL MANAGEMENT SYSTEM</title>
</head>
<body>
	<?php
include('header.php');
	?>
<div id="container">
	  <form>
	  	
  <fieldset>
  		
    <legend>Contact Form</legend>

		    <label for="fname">First Name &nbsp;&nbsp;&nbsp;</label>
		    <input type="text" id="fname" name="firstname" placeholder="Your first name.."><br>

		    <label for="lname">Last Name&nbsp;&nbsp;&nbsp;&nbsp;</label>
		    <input type="text" id="lname" name="lastname" placeholder="Your last name.."><br>

		    <label for="subject">Subject place</label>
		    <textarea id="subject" name="subject" placeholder="Write something.." style="height:20px"></textarea><br>

		    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Submit"><br>
	</fieldset>
		</form><br>
 </div>
		<?php
include('footer.php');
		?>

</body>
</html>