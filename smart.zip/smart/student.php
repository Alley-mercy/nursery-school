<!DOCTYPE html>
<html>
<head>
	<title>SCHOOL MANAGEMENT SYSTEM</title>
</head>

<body bgcolor="#d9d9f2">
	<?php
include('header.php');
?>

<div id="formset">
	  <form>
	  	
  <fieldset>
  		
    <legend>Student Registration Form:</legend>
    	
    <label for="fname">First name:</label>
    <input type="text" id="fname" name="fname" value=""><br>
    <label for="lname">Last name:</label>
    <input type="text" id="lname" name="lname" value=""><br>
    <label for="country">Country &nbsp;&nbsp;&nbsp;</label>
	    <select id="country" name="country">
	      <option >Rwanda</option>
	      <option >Burundi</option>
	      <option >Tanzania</option>
	    </select><br>
	    <label>Gender</label>
	    Male <input type="radio" name="">
	    Female <input type="radio" name="">
	    <br><br>
	    <label>Date of Birth</label>
	    <input type="date" name=""><br>

	    <label for="country">Department &nbsp;&nbsp;</label>
	    <select id="country" name="country">
	      <option >Primary</option>
	      <option >O level</option>
	      <option >A level</option>
	    </select><br><br>
    		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Submit">
    		
  		</fieldset>
	</form>
</div>
	<?php
include('footer.php');
?>
</html>