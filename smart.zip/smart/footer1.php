<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="smart.css">
	<title></title>
</head>
<body>
	<footer>
		<div id="footer1">
			<h1>You need a help?</h1>
			<a href="#">Terms &amp;Conditions</a><br>
		<a href="#">Privacy &amp;Policy</a>
		</div>
	</footer>
</body>
</html>