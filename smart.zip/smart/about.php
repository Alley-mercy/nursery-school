<!DOCTYPE html>
<html>
<head>
	<title>SCHOOL MANAGEMENT SYSTEM</title>
</head>
<body>
			<?php
include('header.php');
?>
		<div class="test">
	  <h1>about what we do :</h1>
	  <p>This a school management system;We do manage school activities .Our students are bright learners !!
	  Helping them to struggle for better future.Our teachers are very smart to teach every course here in our school.</p>
	</div>
	<div class="gallery">
	  <a target="_blank" href="img_5terre.jpeg">
	    <img src="img/img_2.jpeg" alt="Cinque Terre" width="800" height="400">
	  </a>
	</div>

	<div class="gallery">
	  <a target="_blank" href="img_students.jpeg">
	    <img src="img/img_3.jpeg" alt="students" width="800" height="400">
	  </a>
	</div>

	<div class="gallery">
	  <a target="_blank" href="img_lights.jpeg">
	    <img src="img/person_2.jpeg" alt="Northern Lights" width="800" height="400">
	  </a>
	</div>

</body>
<?php
include('footer.php');
?>

</html>