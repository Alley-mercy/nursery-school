<!DOCTYPE html>
<html>
<head>
	<title>SCHOOL MANAGEMENT SYSTEM</title>
</head>
<body>
		<?php
include('header.php');
?>
	<div id="formset">
	  <form>
	  	
  <fieldset>
    <legend>Courses form</legend>
    <label for="name">Cname:</label>
    <input type="text" id="name" name="name" value=""><br>
	    <label for="name">CourseId:</label>
	    <input type="text" name="CourseId" value>
	    Female <input type="radio" name="">
	    <br><br>
	   	<label for="country">Department &nbsp;&nbsp;</label>
	    <select id="country" name="country">
	      <option >Primary</option>
	      <option >O level</option>
	      <option >A level</option>
	    </select><br><br>
    		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Submit">
    		
  		</fieldset>
	</form>
</div>
</body>
	<?php
include('footer.php');
?>
</html>