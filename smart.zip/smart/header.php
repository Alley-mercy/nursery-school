<!DOCTYPE html>
<html>
<head>
	<title>SCHOOL MANAGEMENT SYSTEM</title>
</head>
<link rel="stylesheet" type="text/css" href="smart.css">
<body>
	<div class="header">
		<div class="logo">
			<img src="logo.jpg">
		<div class="menu">
			
<ul>
<li><a  href="index.php">Home</a></li>
<li><a href="student.php">Student</a></li>
<li><a href="teacher.php">Teacher</a></li>
<li><a href="about.php">About Us</a></li>
<li><a href="service.php">Course</a></li>
<li><a href="contact.php">Contact Us</a></li>
</div>
</ul>
		</div>
	</div>
</div>
</body>
</html>
